import csv
import time
import random
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import NoSuchElementException, ElementClickInterceptedException, WebDriverException

# Create a human-like delay
def human_delay(a=1.2, b=3.0):
    time.sleep(random.uniform(a, b))

# Create the Chrome driver with options
def create_driver():
    options = Options()
    options.add_argument("--start-maximized")
    options.add_argument("--disable-blink-features=AutomationControlled")
    return webdriver.Chrome(service=Service(), options=options)

# Simulate typing like a human
def human_typing(element, text):
    for char in text:
        element.send_keys(char)
        time.sleep(random.uniform(0.05, 0.2))

# Try an action with retries
def try_with_retries(action, attempts=3, delay=2):
    for attempt in range(attempts):
        try:
            return action()
        except Exception as e:
            print(f"Attempt {attempt+1} failed: {e}")
            time.sleep(delay + attempt)
    print("All attempts failed.")
    return None

# Extract Chicago citation
def extract_chicago_citation(driver):
    def _extract():
        chicago_xpath = "//div[@id='gs_cit']//tr[3]/td/div"
        return driver.find_element(By.XPATH, chicago_xpath).text
    return try_with_retries(_extract)

# Click the close (X) button
def close_citation_popup(driver):
    try:
        close_btn = driver.find_element(By.ID, "gs_cit-x")
        close_btn.click()
    except:
        pass

# Main scraping function
def scrape_scholar(query, csv_filename="citations.csv"):
    driver = create_driver()
    base_url = "https://scholar.google.com"
    start = 0
    result_index = 1

    with open(csv_filename, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(["Result Number", "Result"])

        while True:
            url = f"{base_url}/scholar?start={start}&q={query.replace(' ', '+')}&hl=en&as_sdt=0,5"
            print(f"\n🧭 Navigating to page {start // 10 + 1} - {url}")

            success = try_with_retries(lambda: driver.get(url))
            if not success:
                print("⚠️ Failed to load the page. Skipping.")
                break

            human_delay(2, 4)

            # Simulate random scroll
            driver.execute_script("window.scrollBy(0, 300);")
            human_delay()
            driver.execute_script("window.scrollBy(0, -150);")

            publications = driver.find_elements(By.CSS_SELECTOR, ".gs_ri")
            if not publications:
                print("No results found or blocked. Retrying...")
                if not try_with_retries(lambda: driver.get(url)):
                    break
                continue

            print(f"📚 Found {len(publications)} results")

            for pub in publications:
                try:
                    print(f"🔍 Processing Result #{result_index}")

                    # Scroll into view for better realism
                    driver.execute_script("arguments[0].scrollIntoView(true);", pub)
                    human_delay(1, 2)

                    # Click the Cite button with retries
                    def click_cite():
                        cite_btn = pub.find_element(By.CSS_SELECTOR, ".gs_fl a.gs_or_cit")
                        cite_btn.click()

                    if not try_with_retries(click_cite):
                        continue

                    human_delay(1, 2)

                    citation = extract_chicago_citation(driver)
                    if citation:
                        writer.writerow([result_index, citation])
                        file.flush()
                        print(f"✅ Saved Result #{result_index}")
                        result_index += 1
                    else:
                        print(f"❌ Could not extract citation for result #{result_index}")

                    close_citation_popup(driver)
                    human_delay()

                except Exception as e:
                    print(f"⚠️ Error processing result #{result_index}: {e}")
                    continue

            # Go to next page
            try:
                next_btn = driver.find_element(By.LINK_TEXT, "Next")
                human_delay()
                next_btn.click()
                start += 10
            except NoSuchElementException:
                print("🚪 No more pages.")
                break

            human_delay(2, 4)

    driver.quit()
    print(f"\n✅ All results saved to {csv_filename}")

# Run the scraper
if __name__ == "__main__":
    search_query = "Suresh Sundaram IISc"
    scrape_scholar(search_query)
