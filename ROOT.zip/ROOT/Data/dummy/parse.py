import csv
import re

def parse_chicago_citation(citation):
    # Initialize default values
    authors = title = journal = year = None

    # Extract authors: from start until the first period
    author_match = re.match(r'^(.*?\.)', citation)
    if author_match:
        authors = author_match.group(1).strip()
        remaining_text = citation[author_match.end():].strip()
    else:
        remaining_text = citation.strip()

    # Extract year: last four-digit number in the citation
    year_match = re.search(r'(\b\d{4}\b)[^\d]*$', remaining_text)
    if year_match:
        year = year_match.group(1)
        remaining_text = remaining_text[:year_match.start()].strip()

    # Extract title and journal
    title_match = re.search(r'"(.*?)"', remaining_text)
    if title_match:
        title = title_match.group(1).strip()
        post_title_text = remaining_text[title_match.end():].strip()
        # Extract journal if mentioned after "In"
        journal_match = re.search(r'In\s+([^,]+)', post_title_text)
        if journal_match:
            journal = journal_match.group(1).strip()
    else:
        # If no quoted title, assume the remaining text before the year is the title
        title = remaining_text

    return authors, title, journal, year

def process_csv(input_csv_path, output_csv_path):
    with open(input_csv_path, mode='r', newline='', encoding='utf-8') as infile:
        csv_reader = csv.reader(infile)
        headers = next(csv_reader)  # Skip header if present

        with open(output_csv_path, mode='w', newline='', encoding='utf-8') as outfile:
            csv_writer = csv.writer(outfile)
            # Write headers for the output CSV
            csv_writer.writerow(['Authors', 'Title', 'Journal', 'Year'])

            for row in csv_reader:
                citation = row[1]  # Assuming the citation is in the second column
                authors, title, journal, year = parse_chicago_citation(citation)
                csv_writer.writerow([authors, title, journal, year])

# Example usage:
input_csv = 'citations_1.csv'  # Replace with your input CSV file path
output_csv = 'parsed_output.csv'  # Desired output CSV file path
process_csv(input_csv, output_csv)
