Training Session Configuration:
learning_rate: 0.001
learning_rate_2: 0.001
dropout_rate: 0.0
hidden_neurons: 100
num_layers: 2
regularization: 0.1
lipschitz_constant: 0.0
partial_rmse: False
missing_beam_probability: {'b1': 0.2, 'b2': 0.15, 'b3': 0.1, 'b4': 0.05}
